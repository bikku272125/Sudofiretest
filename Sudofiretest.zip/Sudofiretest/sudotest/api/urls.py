from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from api.views import CreateCustomerView

router = routers.DefaultRouter()
# router.register(r'create-customer', CreateCustomerView, basename='CreateCustomer')


urlpatterns = [
    # path('api/create-customer', include(router.urls))
    path('', CreateCustomerView.as_view(), name='create-customer'),
]